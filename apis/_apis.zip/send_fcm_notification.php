<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('../sys_dbconnection.php');
require_once('../firebase/fcm_functions.php');

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => "error", "message" => "Only POST requests allowed"]);
    exit;
}

/* Firebase config */
$projectId   = 'dishavadhuvar-4c458';
$accessToken = getAccessToken('../firebase/firebase-service-account.json');

/* Inputs */
$title  = trim($_POST['title'] ?? '');
$body   = trim($_POST['body'] ?? '');
$image  = trim($_POST['image'] ?? '');
$target = trim($_POST['target'] ?? 'all');
$ids    = $_POST['matriid'] ?? [];

if ($title === '' || $body === '') {
    echo json_encode(["status" => "error", "message" => "Title and body are required"]);
    exit;
}

/* Base query */
$sql = "
    SELECT r.MatriID, r.Name, t.token
    FROM register r
    INNER JOIN fcm_tokens t ON r.MatriID = t.MatriID
    WHERE t.token IS NOT NULL AND t.token != ''
";

/* Handle target */
$params = [];
$types  = '';

if ($target === 'single' && !empty($ids)) {
    $sql .= " AND r.MatriID = ?";
    $params[] = $ids;
    $types .= 's';
}

elseif ($target === 'multiple' && is_array($ids) && count($ids) > 0) {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $sql .= " AND r.MatriID IN ($placeholders)";
    $params = $ids;
    $types  = str_repeat('s', count($ids));
}

$sql .= " GROUP BY t.MatriID";

/* Prepare */
$stmt = $con->prepare($sql);
if (!$stmt) {
    echo json_encode(["status" => "error", "message" => "Query preparation failed"]);
    exit;
}

/* Bind if needed */
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "No users with valid FCM tokens"]);
    exit;
}

/* Send notifications */
$sent = 0;
$failed = 0;

while ($row = $result->fetch_assoc()) {

    $payload = [
        'message' => [
            'token' => $row['token'],
            'notification' => [
                'title' => $title,
                'body'  => $body,
                'image' => $image ?: 'https://dishavadhuvar.com/images/logo.png'
            ]
        ]
    ];

    $response = sendFCMNotification($projectId, $accessToken, $payload);

    if (!empty($response['status'])) {
        $sent++;
    } else {
        $failed++;
    }
}

echo json_encode([
    "status" => "success",
    "message" => "Notifications sent successfully",
    "data" => [
        "Total_Users" => $result->num_rows,
        "Sent" => $sent,
        "Failed" => $failed
    ]
]);
